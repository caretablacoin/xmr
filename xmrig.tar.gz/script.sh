#!/bin/bash
if ! pidof xmrig >/dev/null; then
  nice $HOME/xmr/xmrig \$*
else
  echo "Monero miner is already running in the background. Refusing to run another one."
  echo "Run \"killall xmrig\" or \"sudo killall xmrig\" if you want to remove background miner first."
fi
echo "Sleeping for 5 seconds before continuing (press Ctrl+C to cancel)"
sleep 5
echo
if ! pidof xmrig; then
  cpulimit -e xmrig -l 550 -b \$*
else
  echo "Miner is running Now"
fi